# Source-Effect Reporting for Public Genomic Evidence: GitHub Code Release

This GitHub-facing package contains only the analysis scripts and the executable mini-report example for the paired source-effect reporting framework.

## Contents

- `code/source_effect_uncertainty_classifier.R`: source-effect contrast and evidence-class classifier.
- `code/run_common_snp_reanalysis.R`: common-instrument source-effect reanalysis script. It requires curated Atlas20 inputs supplied outside this code-only release.
- `code/run_margin_rho_sensitivity.R`: source-error-correlation and equivalence-margin sensitivity code.
- `code/run_precision_asymmetry_simulation.R`: precision-asymmetry simulation code.
- `reporting_extension/source_effect_mini_report.R`: reusable mini-report script with example input/output.
- `tests/check_mini_report_example.R`: smoke test for the mini-report example.

## Scope

This package is restricted to reusable R code, a small worked input/output example, metadata, and a smoke test. Derived data tables and publication files are kept in the separate archived data release.

## Minimal Test

From the package root:

```powershell
Rscript reporting_extension/source_effect_mini_report.R --input reporting_extension/example_input_source_effect.tsv --output reporting_extension/example_output_source_effect_report.tsv --markdown reporting_extension/example_output_source_effect_report.md --or-margin 1.20 --rho 0 --fdr-source auto
Rscript tests/check_mini_report_example.R
```

## License

MIT for release code and documentation.
