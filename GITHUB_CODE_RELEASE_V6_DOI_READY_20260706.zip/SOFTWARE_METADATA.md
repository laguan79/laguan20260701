# Software Metadata

- Project name: Source-Effect Reporting for Public Genomic Evidence
- Package type: GitHub code release
- Programming language: R
- Core requirements: R and data.table for the executable mini-report example; additional analysis scripts may require TwoSampleMR and derived input tables.
- License: MIT for release code and documentation.
- Directly runnable component: source-effect mini-report example.
- Scope boundary: reusable R code, a small worked input/output example, metadata, and a smoke test only.
