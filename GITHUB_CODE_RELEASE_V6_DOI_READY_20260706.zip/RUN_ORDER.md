# Run Order

This is a code-only GitHub package.

## Directly Runnable Example

```powershell
Rscript reporting_extension/source_effect_mini_report.R --input reporting_extension/example_input_source_effect.tsv --output reporting_extension/example_output_source_effect_report.tsv --markdown reporting_extension/example_output_source_effect_report.md --or-margin 1.20 --rho 0 --fdr-source auto
Rscript tests/check_mini_report_example.R
```

## Scripts Requiring Curated Inputs

The scripts under `code/` document the analysis implementation. Scripts that recompute the common-SNP reanalysis, rho/margin sensitivity, or precision-asymmetry simulation require the curated derived input tables described in the archived data/reproducibility release.

## Scope Boundary

This package is restricted to reusable R code, a small worked input/output example, metadata, and a smoke test. Derived data tables and publication files are kept in the separate archived data release.
